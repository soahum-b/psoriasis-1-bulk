#!/usr/bin/env python
"""
Dock a shard of the ligand library against one target with AutoDock Vina.

Usage:
    python dock_target.py --target RORC --shard 0 --nshards 100 \
        --ligand_dir ligands/pdbqt --receptor_dir receptors --out results/RORC

Designed for SLURM array jobs: each array task handles one shard of the
pre-prepared ligand PDBQT files. Reads the Vina box from
<receptor_dir>/<target>_receptor.box.txt.
"""
import os, glob, json, time, argparse

def read_box(box_txt):
    c={}
    for ln in open(box_txt):
        if "=" in ln:
            k,v=ln.split("=")
            c[k.strip()]=float(v.strip())
    center=[c["center_x"],c["center_y"],c["center_z"]]
    size=[c["size_x"],c["size_y"],c["size_z"]]
    return center,size

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--target",required=True)
    ap.add_argument("--shard",type=int,default=0)
    ap.add_argument("--nshards",type=int,default=1)
    ap.add_argument("--ligand_dir",default="ligands/pdbqt")
    ap.add_argument("--receptor_dir",default="receptors")
    ap.add_argument("--out",default="results")
    ap.add_argument("--exhaustiveness",type=int,default=16)
    ap.add_argument("--n_poses",type=int,default=10)
    ap.add_argument("--cpu",type=int,default=int(os.environ.get("SLURM_CPUS_PER_TASK",4)))
    args=ap.parse_args()

    from vina import Vina
    rec=f"{args.receptor_dir}/{args.target}_receptor.pdbqt"
    center,size=read_box(f"{args.receptor_dir}/{args.target}_receptor.box.txt")
    ligs=sorted(glob.glob(f"{args.ligand_dir}/*.pdbqt"))
    shard=ligs[args.shard::args.nshards]  # stride partition
    outdir=f"{args.out}/poses"; os.makedirs(outdir,exist_ok=True)
    os.makedirs(args.out,exist_ok=True)

    # Reuse one receptor grid across all ligands in the shard (compute maps once)
    v=Vina(sf_name='vina',cpu=args.cpu,verbosity=0)
    v.set_receptor(rec)
    v.compute_vina_maps(center=center,box_size=size)

    results=[]; t0=time.time()
    for i,lp in enumerate(shard):
        name=os.path.basename(lp).replace(".pdbqt","")
        try:
            v.set_ligand_from_file(lp)
            v.dock(exhaustiveness=args.exhaustiveness,n_poses=args.n_poses)
            e=v.energies(n_poses=1)
            v.write_poses(f"{outdir}/{name}_out.pdbqt",n_poses=1,overwrite=True)
            results.append({"ligand":name,"affinity":float(e[0][0])})
        except Exception as ex:
            results.append({"ligand":name,"affinity":None,"error":str(ex)[:120]})
        if (i+1)%50==0:
            print(f"[{args.target} shard {args.shard}] {i+1}/{len(shard)} {time.time()-t0:.0f}s",flush=True)
    json.dump(results,open(f"{args.out}/results_shard{args.shard:04d}.json","w"))
    print(f"[{args.target} shard {args.shard}] DONE {len(results)} in {time.time()-t0:.0f}s")

if __name__=="__main__":
    main()
