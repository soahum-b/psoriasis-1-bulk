#!/usr/bin/env python
"""
Prepare 3D ligand PDBQT files from an SDF (or SMILES CSV) for docking.
ETKDGv3 embedding + MMFF minimization + Meeko PDBQT export.

Usage:
    python prepare_ligands.py --sdf ligands/screening_library_3d.sdf --out ligands/pdbqt
    python prepare_ligands.py --smiles_csv library.csv --smiles_col smiles \
        --id_col chembl_id --out ligands/pdbqt
"""
import os, argparse, subprocess, tempfile
from rdkit import Chem
from rdkit.Chem import AllChem

def embed(mol):
    mol=Chem.AddHs(mol)
    p=AllChem.ETKDGv3(); p.randomSeed=42
    if AllChem.EmbedMolecule(mol,p)!=0:
        p.useRandomCoords=True
        if AllChem.EmbedMolecule(mol,p)!=0: return None
    try: AllChem.MMFFOptimizeMolecule(mol,maxIters=500)
    except: pass
    return mol

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--sdf"); ap.add_argument("--smiles_csv")
    ap.add_argument("--smiles_col",default="smiles"); ap.add_argument("--id_col",default="chembl_id")
    ap.add_argument("--out",default="ligands/pdbqt")
    args=ap.parse_args()
    os.makedirs(args.out,exist_ok=True)

    # Build a combined 3D SDF first
    tmp_sdf=os.path.join(args.out,"_prepared_3d.sdf")
    w=Chem.SDWriter(tmp_sdf); n=0
    if args.sdf:
        for m in Chem.SDMolSupplier(args.sdf,removeHs=False):
            if m is None: continue
            name=m.GetProp("_Name") if m.HasProp("_Name") else f"mol{n}"
            # already 3D in this project's SDF; write as-is
            w.write(m); n+=1
    else:
        import csv
        for row in csv.DictReader(open(args.smiles_csv)):
            m=Chem.MolFromSmiles(row[args.smiles_col])
            if m is None: continue
            m=embed(m)
            if m is None: continue
            m.SetProp("_Name",row[args.id_col]); w.write(m); n+=1
    w.close()
    print(f"embedded {n} molecules -> {tmp_sdf}")

    # Meeko: SDF -> per-molecule PDBQT
    subprocess.run(["mk_prepare_ligand.py","-i",tmp_sdf,"--multimol_outdir",args.out],check=True)
    npdbqt=len([f for f in os.listdir(args.out) if f.endswith(".pdbqt")])
    print(f"wrote {npdbqt} ligand PDBQT files to {args.out}")

if __name__=="__main__":
    main()
