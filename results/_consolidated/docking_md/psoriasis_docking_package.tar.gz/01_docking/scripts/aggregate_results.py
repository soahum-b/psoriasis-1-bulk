#!/usr/bin/env python
"""Aggregate per-shard docking JSON into one ranked CSV with descriptors."""
import os, glob, json, argparse, csv

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--target",required=True)
    ap.add_argument("--results_dir",default=None)
    ap.add_argument("--library_csv",default="ligands/screening_library.csv")
    args=ap.parse_args()
    rd=args.results_dir or f"results/{args.target}"
    rows=[]
    for jf in sorted(glob.glob(f"{rd}/results_shard*.json")):
        rows.extend(json.load(open(jf)))
    valid=[r for r in rows if r.get("affinity") is not None]
    valid.sort(key=lambda x:x["affinity"])
    # merge descriptors
    lib={}
    if os.path.exists(args.library_csv):
        for r in csv.DictReader(open(args.library_csv)): lib[r.get("chembl_id",r.get("id"))]=r
    out=f"{rd}/{args.target}_docking_ranked.csv"
    with open(out,"w",newline="") as f:
        cols=["rank","ligand","affinity"]+[c for c in ("smiles","mw","logp","qed") ]
        w=csv.writer(f); w.writerow(cols)
        for i,r in enumerate(valid,1):
            d=lib.get(r["ligand"],{})
            w.writerow([i,r["ligand"],round(r["affinity"],3),
                        d.get("smiles",""),d.get("mw",""),d.get("logp",""),d.get("qed","")])
    print(f"{len(valid)}/{len(rows)} docked OK -> {out}")
    if valid:
        print(f"best {valid[0]['ligand']} {valid[0]['affinity']:.2f} | "
              f"top-10 mean {sum(r['affinity'] for r in valid[:10])/min(10,len(valid)):.2f} kcal/mol")

if __name__=="__main__":
    main()
