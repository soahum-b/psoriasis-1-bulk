#!/usr/bin/env python
"""
Resolve ZINC22/CartBlanche22 purchasability for library compounds by SMILES.

Run this when the ZINC22 backend is responsive (the interactive session hit a
sustained outage on the similarity/random endpoints). It queries CartBlanche22
directly over HTTP — no MCP layer needed on the cluster.

Usage:
    python resolve_purchasability.py --library ligands/screening_library.csv \
        --smiles_col smiles --id_col chembl_id --dist 0 --out purchasability.csv

--dist 0  exact structure match (fast); --dist 1..4 similarity (slower).
Also expands the deck: with --expand and --dist>=1, writes purchasable analogs.
"""
import argparse, csv, json, time, sys
try:
    import requests
except ImportError:
    sys.exit("pip install requests")

BASE="https://cartblanche22.docking.org"

def search_smiles(smiles, dist=0, max_results=50, poll_timeout=120):
    # CartBlanche async search: POST returns a task id; poll the result endpoint.
    r=requests.post(f"{BASE}/search/smiles",
                    data={"smiles":smiles,"dist":dist,"max_results":max_results,
                          "database":"zinc22","output_fields":"zinc_id,smiles,catalogs"},
                    timeout=30)
    r.raise_for_status()
    # Response may be direct JSON or a task handle depending on server load
    try:
        j=r.json()
    except Exception:
        return []
    if isinstance(j,dict) and j.get("task_id"):
        url=f"{BASE}/search/result/{j['task_id']}"
        t0=time.time()
        while time.time()-t0<poll_timeout:
            rr=requests.get(url,timeout=30)
            if rr.status_code==200:
                try: return rr.json().get("records",[])
                except Exception: pass
            time.sleep(5)
        return []
    return j.get("records",[]) if isinstance(j,dict) else j

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--library",required=True)
    ap.add_argument("--smiles_col",default="smiles")
    ap.add_argument("--id_col",default="chembl_id")
    ap.add_argument("--dist",type=int,default=0)
    ap.add_argument("--out",default="purchasability.csv")
    args=ap.parse_args()
    rows=list(csv.DictReader(open(args.library)))
    out=[]
    for i,row in enumerate(rows):
        sm=row[args.smiles_col]
        try:
            recs=search_smiles(sm,dist=args.dist)
        except Exception as e:
            recs=[]; print(f"  {row[args.id_col]}: ERR {str(e)[:60]}")
        cats=[]
        for rec in recs:
            for c in (rec.get("catalogs") or []):
                if c.get("purchase"): cats.append(c.get("catalog_name"))
        out.append({"id":row[args.id_col],"smiles":sm,
                    "n_zinc_matches":len(recs),
                    "zinc_id":recs[0]["zinc_id"] if recs else "",
                    "purchasable":bool(cats),"catalogs":";".join(sorted(set(cats)))[:200]})
        if (i+1)%25==0: print(f"  {i+1}/{len(rows)} resolved")
        time.sleep(0.3)
    with open(args.out,"w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
    npurch=sum(1 for r in out if r["purchasable"])
    print(f"{npurch}/{len(out)} purchasable -> {args.out}")

if __name__=="__main__":
    main()
