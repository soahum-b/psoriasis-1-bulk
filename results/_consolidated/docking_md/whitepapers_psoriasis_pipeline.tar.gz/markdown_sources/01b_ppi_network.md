# White Paper 1b — The protein–protein interaction network: a guided explainer

**Pipeline step:** PPI network construction & hub analysis (between DEGs and pathways)
**Inputs:** 2,379 significant meta-analysis DEGs
**Outputs:** `fig_ppi_network.png`, `ppi_hub_genes.csv`, `lead_network_centrality.csv`

---

> **How to read this paper.** Unlike the other white papers in this set, this one is written as a
> teaching document. It assumes no prior network-biology background. Section 2 explains what the
> picture *is* — what every dot, line, colour, and size means. Section 3 explains the biological idea
> behind it. Sections 4–7 explain, step by step, how each number was actually computed. Section 8
> gives the results for our psoriasis network and what they tell us about the leads.

## 1. Why build a network at all?

The differential-expression analysis (White Paper 1) gives us a *list* of 2,379 genes that change in
psoriasis. But a list treats every gene as independent, and biology is not independent — proteins act
in **teams**. A transcription factor switches on a set of targets; a kinase phosphorylates a
substrate; a receptor passes a signal to an adaptor. A protein–protein interaction (PPI) network turns
the flat list into a **map of who works with whom**, and that map lets us ask a question a list cannot
answer: *which genes are the organizers of the disease response, and which are just followers?*

This is the concept of **network medicine** — the idea that disease is rarely the fault of one gene in
isolation, but emerges from the wiring of a module of interacting proteins, and that the most
important therapeutic targets are often the best-connected nodes in that wiring [@network_medicine;
@network_biology].

## 2. How to read the network picture

The main figure (`fig_ppi_network.png`, left panel) is a **node–link diagram**. Here is the complete
visual grammar:

- **Each dot (node) is one protein**, encoded by one of our differentially expressed genes. If a gene
  is in the list but STRING has no high-confidence partner for it, it has no dot in the connected map
  (it is an "isolated" node — see §5).
- **Each line (edge) connecting two dots means those two proteins are known to interact** — physically
  bind, sit in the same complex, act in the same pathway, or are reproducibly reported together. The
  line is drawn *only* when the evidence for that interaction is strong (see §4). A line is **not** a
  correlation in our data; it comes from decades of prior experiments curated in the STRING database.
- **The size of a dot = its degree = how many partners it has.** Big dots are highly connected
  proteins ("hubs"); small dots have one or two partners. (§6)
- **The colour of a dot = which functional module (community) it belongs to.** The network naturally
  breaks into clusters of proteins that interact more with each other than with the rest; each cluster
  gets its own colour, and we labelled them by their dominant biology (immune/JAK-STAT, cell-cycle,
  interferon, etc.). (§7)
- **A black ring around a dot marks one of our three leads** (STAT3, RORC, JAK3), so you can see where
  they sit in the wiring.

The right panel is a plain bar chart of the most "central" proteins (§6.2) with the leads highlighted
in red — it is the quantitative version of "who are the organizers."

So when you look at the figure, the story is read like this: *clusters of one colour* are functional
teams; *big dots* are the captains of those teams; *lines* are the working relationships; and the
*ringed dots* show whether our drug targets are captains or bench players.

## 3. Where the interactions come from: the STRING database

We did not measure the interactions ourselves — that would take thousands of experiments. Instead we
queried **STRING** (version 12.0), a database that aggregates known and predicted protein–protein
associations for thousands of organisms from multiple evidence sources [@string_v12]. For each
possible pair of proteins, STRING combines evidence from several independent **channels**:

- **Experiments** — physical-interaction assays (co-immunoprecipitation, two-hybrid, affinity
  purification).
- **Databases** — manually curated pathway databases (e.g. Reactome, KEGG).
- **Text-mining** — co-mention in the abstracts and full text of the scientific literature.
- **Co-expression** — genes repeatedly switched on together across many experiments.
- **Neighbourhood / fusion / co-occurrence** — genomic-context evidence, mostly informative in
  microbes.

Each channel yields a sub-score, and STRING fuses them into a single **combined score** between 0 and
1 (reported as 0–1000). A combined score of 0.7 means: *integrating all the evidence, there is roughly
a 70% expected probability that this interaction is biologically genuine.* This score is the single
most important knob in the whole analysis, which is the subject of the next section.

## 4. Step 1 — Choosing a confidence threshold

If we drew an edge for every non-zero STRING score, the network would be a hairball of mostly
spurious, weakly-supported links. So we set a **confidence threshold** and kept only edges at or above
it. We used **combined score ≥ 0.700 ("high confidence")**.

- Below 0.4 = low confidence (mostly noise for our purpose).
- 0.4–0.7 = medium confidence.
- **≥ 0.7 = high confidence** (our choice).
- ≥ 0.9 = highest confidence (very strict).

Choosing 0.700 is a deliberate trade-off: high enough that the edges are trustworthy, not so high that
the network fragments into disconnected pieces. Every edge in our figure therefore represents an
association with ≥70% integrated support; the *mean* score of the edges we kept was 0.85, i.e. the
retained interactions are comfortably above the floor.

## 5. Step 2 — Mapping genes to proteins, and what "isolated" means

STRING is a database of *proteins*, so first every gene symbol was mapped to its STRING protein
identifier (the connector's `map_string_ids` step). Of our **2,379 input genes, 1,791 mapped** to a
human STRING protein; **588 did not** — these are mostly non-coding RNAs, pseudogenes, and
uncharacterized loci that have no protein and therefore cannot be in a protein network. This is an
honest, reported number, not a silent drop.

Of the 1,791 mapped proteins, **1,062 had at least one high-confidence partner** (these form the
visible network) and **729 were "isolated"** — real proteins that simply have no ≥0.7 interaction with
any other protein in our specific gene list. Isolation does not mean the protein is unimportant; it
means that at our confidence threshold, within this particular set of genes, it has no strong partner.
Isolated nodes are excluded from the connectivity picture because a dot with no lines carries no
network information.

## 6. Step 3 — Measuring importance: the two centrality metrics

"Importance" in a network has more than one meaning, so we computed two complementary measures.

### 6.1 Degree — "how many partners?"

The **degree** of a protein is simply the number of edges attached to its dot — how many
high-confidence partners it has in the network. A high-degree protein is a **hub**: it touches many
others. Degree is the size of each dot in the figure. The biological intuition — that highly-connected
hub proteins tend to be functionally essential — is a foundational result of network biology
[@lethality_centrality].

### 6.2 Betweenness — "how much of a bottleneck?"

Degree counts *neighbours*; it does not capture whether a protein is a **bridge** between different
parts of the network. For that we use **betweenness centrality**, defined by Freeman [@freeman_betweenness].

The idea: for every pair of proteins in the network, there is a shortest path (the fewest edges) that
connects them. Betweenness asks, for a given protein X: *of all the shortest paths between all other
pairs of proteins, what fraction pass through X?* Formally,

```
betweenness(X) = sum over all pairs (s,t) of  [ paths(s,t) through X / all paths(s,t) ]
```

normalized to lie between 0 and 1. A protein with high betweenness is a **bottleneck**: information
(or signal) flowing from one module of the network to another has to pass through it. Bottleneck
proteins are often *more* therapeutically interesting than mere high-degree hubs, because disrupting a
bridge can sever communication between whole functional modules. We computed betweenness on the giant
connected component (984 proteins) using the standard shortest-path algorithm.

**Degree vs betweenness, in one line:** a high-degree protein has many friends; a high-betweenness
protein stands at a crossroads. STAT3, as we will see, is both — but it is *especially* a crossroads.

## 7. Step 4 — Finding functional modules: community detection

Real networks are not uniform — they have **communities**: groups of proteins that interact densely
among themselves and sparsely with the rest. Detecting these communities reveals the functional
sub-programs of the disease.

We used the **Louvain method** [@louvain], a fast, widely-used algorithm that finds communities by
maximizing **modularity** — a score that is high when there are many edges *inside* communities and
few edges *between* them. The algorithm groups nodes, then repeatedly merges and reshuffles them until
the modularity can no longer improve. The output is an assignment of every protein to exactly one
community; we then coloured the figure by community and named each one after the biology of its
dominant members.

## 8. Results: what our psoriasis network shows

The high-confidence network has **1,062 connected proteins and 5,430 interactions**, and it breaks
into biologically coherent modules:

| Module (colour) | Character | Notable members |
|-----------------|-----------|-----------------|
| Immune / JAK-STAT / chemokine | Mostly up-regulated | STAT3, JAK3, CD8A, CXCL10, chemokine receptors |
| Cell cycle / proliferation | Up-regulated | CDK1, CCNB1, AURKB, PLK1, BUB1 (keratinocyte hyperproliferation) |
| Interferon / antiviral | Up-regulated | STAT1, ISG15, IRF7, MX1 |
| ECM / matrix remodeling | Down-regulated | FN1, MMP9, decorin, collagens |
| Lipid / metabolism | Mixed | APOE, RORC, PPARGC1A |

**The key finding — the leads are network-central, which independently validates them:**

| Lead | Degree | Degree rank | Betweenness | Betweenness rank |
|------|--------|-------------|-------------|------------------|
| **STAT3** | 63 | 22 / 1,791 (99th pctile) | 0.111 | **2nd of 984** |
| **JAK3** | 24 | 140 (92nd) | 0.006 | 169 |
| **RORC** | 10 | 265 (84th) | 0.006 | 160 |

STAT3 is the **second-highest betweenness protein in the entire network** (behind only fibronectin,
FN1) — it is the single most important *bridge* linking the immune/JAK-STAT module to the rest of the
psoriatic response. This is a completely independent line of evidence for STAT3 as the anchor lead: it
was chosen originally on differential expression and pathway grounds, and the network topology — which
knows nothing about those analyses — places it at the crossroads of the disease wiring. STAT3 and JAK3
fall in the **same community**, reinforcing the JAK3 → STAT3 signaling axis the lead set encodes.

The raw top-degree hubs (CDK1, CCNB1, AURKB, PLK1) are the cell-cycle proliferation machinery — the
molecular signature of the keratinocyte hyperproliferation that defines a psoriatic plaque — and they
are retained as secondary candidates.

## 9. How our approach improves on the standard

Many published pipelines build a PPI network on only the handful of top DEGs and read off hubs by
degree alone. We built the network on the **full significant DEG set (2,379 genes)**, applied a
**high-confidence threshold**, and used **two centrality measures plus community detection** — so the
hubs are discovered *de novo* from the whole disease signature rather than assumed, and the leads'
centrality is a genuine out-of-sample validation. The network was visualized following the same
node–link conventions established by tools such as Cytoscape [@cytoscape].

## 10. Deliverables

- **`fig_ppi_network.png`** — the annotated network (community colours, hub sizes, ringed leads) plus
  the centrality bar chart.
- **`ppi_hub_genes.csv`** — every connected protein with degree, betweenness, community, direction,
  and druggability annotation.
- **`lead_network_centrality.csv`** — the lead centrality summary above.

## 11. Caveats

- STRING associations include predicted and text-mined links, not only direct physical binding; a
  high combined score means strong *aggregate* evidence, not a proven physical complex.
- Centrality is a property of *this* network at *this* threshold; changing the confidence cutoff or the
  gene set will shift the exact ranks (though STAT3's prominence is robust).
- Isolated and unmapped genes carry no network information — absence of a dot is not evidence of
  biological unimportance.

## References
