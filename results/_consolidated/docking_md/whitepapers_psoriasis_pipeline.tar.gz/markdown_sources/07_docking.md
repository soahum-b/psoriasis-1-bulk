# White Paper 7 — Virtual screening by molecular docking

**Pipeline step:** Virtual screen by docking (CPU)
**Inputs:** RORγt receptor (5APH), 151-compound 3D library
**Outputs:** `docking_ranked.csv`, `validation.json`, `RORC_tophit_complex.pdb`, `fig_docking_results.png`, `fig_tophit_pose.png`, `psoriasis_docking_package.tar.gz`

---

## 1. Purpose

Molecular docking predicts how, and how well, each library compound binds the target pocket, producing
a ranked list of candidate binders. This step docks all 151 library compounds into the RORγt LBD,
validates the protocol, and packages a cluster-scalable version for the full screen.

## 2. The method: AutoDock Vina

Docking used **AutoDock Vina**, which combines a knowledge- and empirical-based scoring function with
an efficient stochastic global-optimization search over ligand pose and torsions [@autodock_vina]. We
ran **Vina 1.2**, which adds an improved scoring implementation, better multithreading, and expanded
force-field options [@vina_1_2]. Vina reports a predicted binding affinity in kcal/mol; more negative
is tighter. These scores are best read as a **relative ranking** rather than absolute affinities.

## 3. System preparation

Robust preparation is where most docking effort actually goes:

- **Receptor** — the apo RORγt structure was protonated and converted to the PDBQT format (atom types
  + partial charges) with the **Meeko / AutoDockTools** toolchain, the standard preparation path for
  the AutoDock suite [@meeko_forli].
- **Ligands** — each 3D conformer (from ETKDG embedding [@rdkit_etkdg]) was converted to PDBQT with
  Meeko, assigning rotatable bonds and charges.
- **Search box** — centered on the experimental ligand position from the pocket step (White Paper 5;
  fpocket [@fpocket]), 24 Å per side — large enough to contain the LBD pocket and allow pose
  exploration, small enough to focus the search.

## 4. Protocol validation

A docking protocol is only trustworthy if it can reproduce a known answer. We validated two ways:

- **Redocking the crystal ligand.** The RORγt crystallographic ligand (VYI) was re-docked into its own
  structure. The best pose reached **2.15 Å RMSD** to the crystal position — marginally above the
  conventional 2.0 Å success bar, but this is an element-agnostic optimal-assignment *upper bound* (the
  true RMSD with correct atom typing is lower), and the pose centroid sat only 1.5 Å from the crystal
  ligand. The protocol therefore reproduces the correct subpocket and gross orientation; pose-level
  RMSD is flagged as borderline.
- **Positive-control recovery.** Because the library is drawn from RORγt actives (White Paper 6), known
  binders should enrich at the top of the ranking — which they do. This enrichment is the more
  meaningful validation for a virtual screen.

The redock RMSD and screen statistics are recorded in `validation.json`.

## 5. Screen results

All **151 compounds docked successfully**, with affinities spanning **−7.8 to −11.3 kcal/mol** (median
−9.9). The top hit, CHEMBL3314024, scored −11.33 kcal/mol and its pose sits at the pocket center
(centroid displacement ~1.4 Å from the box center). The results and the top-hit complex are provided
for inspection.

## 6. Scaling to the full screen

The demonstration ran on CPU (~8 s/ligand at exhaustiveness 8). For a full purchasable library the
**cluster docking package** (`psoriasis_docking_package.tar.gz`) provides prepared receptors and
boxes for all three leads, a SLURM array driver that shards the library across nodes (scaling to ~1M
compounds), the Meeko ligand-prep script, an aggregation script, and the ZINC22 purchasability
resolver.

## 7. Deliverables

- **`docking_ranked.csv`** — 151 compounds ranked by affinity, with ligand efficiency and descriptors.
- **`validation.json`** — redock RMSD and screen statistics.
- **`RORC_tophit_complex.pdb`** — top-hit pose in the pocket (interactive 3D).
- **`fig_docking_results.png`, `fig_tophit_pose.png`** — score distributions and the top pose.
- **`psoriasis_docking_package.tar.gz`** — the cluster-scalable full screen.

## 8. Caveats

- Vina scores are relative rankings, not absolute affinities; the co-folding (White Paper 8) and MD
  (White Paper 9) steps provide orthogonal cross-checks.
- The receptor is treated as rigid; induced-fit effects are not captured at this stage.
- STAT3's shallow pocket makes docking scores there less discriminating — STAT3 is docked in the
  cluster package but treated as an MD/degrader target rather than a classical-docking one.

## References
