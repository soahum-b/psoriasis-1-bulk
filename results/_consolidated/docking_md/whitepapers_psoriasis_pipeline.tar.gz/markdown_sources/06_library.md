# White Paper 6 — Preparing the purchasable screening library

**Pipeline step:** Prepare purchasable screening library (ZINC22)
**Inputs:** RORγt (CHEMBL1741186) bioactivity data
**Outputs:** `screening_library.csv`, `screening_library_3d.sdf`, `fig_library_properties.png`, `LIBRARY_README.md`

---

## 1. Purpose

A virtual screen needs a library of candidate molecules. This step assembles a **RORγt-focused,
drug-like, 3D-ready** compound deck and documents an important deviation: the intended ZINC22
purchasable source was unavailable, so the library was sourced from ChEMBL bioactivity space instead —
with purchasability deferred to a resolver script.

## 2. Design intent and the ZINC22 outage

The original plan was a purchasable library from **ZINC22** — a catalog of commercially available
compounds. During execution, the ZINC22/CartBlanche22 similarity and random-sampling endpoints timed
out persistently; only the exact-ID lookup responded. Rather than block the pipeline, we pivoted to a
**target-focused bioactivity library** and shipped a `resolve_purchasability.py` script (in the
docking package) to annotate purchasability once the backend recovers. This substitution is stated
openly in every downstream artifact.

## 3. Sourcing from ChEMBL bioactivity space

The library was built from **ChEMBL** actives against the RORγt target (CHEMBL1741186) [@chembl_2024].
We pulled 714 distinct compounds with measured potency (**pChEMBL ≥ 7**, i.e. ≤ 100 nM) [@pchembl],
fetched SMILES for the top 250 by potency plus similarity analogs, giving 251 unique structures. A
bioactivity-sourced deck has a decisive advantage for a demonstration screen: it contains **built-in
positive controls** (known binders), so the screen's ability to recover them is directly testable.

## 4. Standardization and drug-likeness filtering

Raw database structures were standardized with **RDKit** [@rdkit_etkdg] — taking the largest organic
fragment and neutralizing charges — then filtered for drug-likeness with a Lipinski-style rule set:
at most one Ro5 violation, molecular weight 250–600 Da, ≤ 12 rotatable bonds, and TPSA ≤ 160 Å². This
removed non-drug-like outliers and left **151 compounds** (QED 0.28–0.85, MW 278–588 Da).

## 5. 3D conformer generation

Docking requires 3D structures. Each molecule was embedded with RDKit's **ETKDG** algorithm —
Experimental-Torsion Knowledge Distance Geometry, which biases distance-geometry embedding toward
torsion angles observed in crystallographic data — followed by MMFF force-field minimization
[@rdkit_etkdg]. All 151 compounds embedded successfully (seed fixed for reproducibility), producing
`screening_library_3d.sdf`.

## 6. Library properties

The final deck has median MW 479 Da, cLogP 4.5, QED 0.53, and TPSA 72 Å² — a lead-like-to-drug-like
distribution appropriate for an LBD pocket. The property distributions are plotted in
`fig_library_properties.png`.

## 7. Deliverables

- **`screening_library.csv`** — 151 compounds with descriptors and ChEMBL provenance.
- **`screening_library_3d.sdf`** — 3D conformers ready for docking.
- **`fig_library_properties.png`** — MW/logP/QED/TPSA and related distributions.
- **`LIBRARY_README.md`** — full provenance, the ZINC22 outage, and the deferred purchasability plan.

## 8. Caveats

- The library is **bioactivity-sourced, not confirmed-purchasable**; purchasability resolution is
  pending ZINC22 recovery (resolver script provided).
- A target-focused deck is ideal for method validation but is not an unbiased chemical-space sample;
  the full-scale docking package supports substituting a larger purchasable library.

## References
