# White Paper 5 — Binding-pocket detection & structural druggability

**Pipeline step:** Binding-pocket detection & structural druggability
**Inputs:** lead structures (apo), reference ligand positions
**Outputs:** `pocket_report.csv`, `pocket_druggability_summary.csv`, `fig_pockets_druggability.png`

---

## 1. Purpose

Knowledge-base tractability (White Paper 2) tells us whether a target has *attracted* chemistry;
structural druggability tells us whether its pocket is *physically capable* of binding a drug-like
molecule. This step detects pockets on each lead structure and scores their druggability directly from
geometry and chemistry — the structural counterpart to the annotation-based assessment.

## 2. The method: fpocket

Pocket detection used **fpocket**, an open-source geometry-based cavity detector [@fpocket]. fpocket
places "alpha spheres" that fit between protein atoms; clusters of appropriately-sized spheres define
candidate pockets. Critically, fpocket reports a **druggability score** (0–1) trained to discriminate
pockets that bind drug-like ligands from those that do not, using descriptors such as pocket volume,
hydrophobicity, and enclosure. This score is the structural analog of the Open Targets tractability
bucket.

## 3. Preparation and pocket matching

Each structure was stripped of its ligand and waters to an **apo** form (STAT3 4,172, RORC 2,179, JAK3
2,333 protein atoms) before pocket detection, so that fpocket found the pocket *de novo* rather than
around the ligand. To identify which detected pocket corresponds to the functional site, we matched
pockets to the known crystallographic ligand position by **ligand-atom overlap** (protein pocket
atoms within 4.5 Å of the reference ligand) — more robust than centroid distance when a protein has
several nearby cavities.

## 4. Results and interpretation

| Lead | Matched pocket | fpocket druggability | Volume (Å³) | Interpretation |
|------|----------------|---------------------|-------------|----------------|
| **RORC / RORγt** | LBD orthosteric | **0.936** | 1,124 | Textbook druggable pocket |
| **JAK3** | ATP site | 0.016 | 1,860 | Chemically validated despite low geometric score |
| **STAT3** | SH2 / core | 0.001 | 199 | Genuinely shallow — a hard TF target |

Three distinct situations emerge, and reading them correctly is the point of the step:

- **RORγt** scores 0.94 — a deep, enclosed, hydrophobic ligand-binding domain pocket. Structural and
  chemical druggability agree, making it the natural primary docking target.
- **JAK3** scores low *in this crystal form* even though its ATP site is one of the most drugged
  pockets in medicine (6,069 potent inhibitors). fpocket's geometric score is sensitive to the
  particular conformation and the bound-ligand-induced cleft; the discrepancy is a caution against
  reading fpocket in isolation, not evidence of undruggability.
- **STAT3** scores ~0.001 — the SH2/core surface is genuinely shallow and solvent-exposed. This is the
  structural reason the field has moved to degrader and bivalent chemistry for STAT3, consistent with
  the degrader-class ligand in the chosen structure. The low score is a true finding, not an artifact.

The privileged-pocket logic underlying this interpretation is the druggable-genome framework
[@druggable_genome].

## 5. Docking-box definition

For each lead the docking search center was set from the **experimental ligand position** rather than
the fpocket centroid, because the crystallographic ligand is the most reliable marker of the
functional site. These centers feed the docking step (White Paper 7).

## 6. Deliverables

- **`pocket_report.csv`** — every detected pocket with druggability, volume, and hydrophobicity.
- **`pocket_druggability_summary.csv`** — the matched functional pocket per lead.
- **`fig_pockets_druggability.png`** — 3D pocket views plus a druggability-comparison panel.

## 7. Caveats

- fpocket scores are conformation-dependent; a single crystal form can under- or over-score a pocket
  (JAK3 is the clear example here).
- Structural druggability and chemical tractability are complementary — neither alone is decisive.

## References
