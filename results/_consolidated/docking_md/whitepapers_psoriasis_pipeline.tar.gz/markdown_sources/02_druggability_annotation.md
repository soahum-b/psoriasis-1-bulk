# White Paper 2 — Druggability annotation via knowledge bases

**Pipeline step:** Druggability annotation via knowledge bases
**Inputs:** candidate gene list (168 genes, STAT3-anchored)
**Outputs:** `druggability_annotation.csv`, `fig_druggability_landscape.png`

---

## 1. Purpose

A differentially expressed gene is a biological hypothesis; a *druggable* differentially expressed gene
is a therapeutic hypothesis. This step annotates each candidate protein with what is known about its
amenability to small-molecule intervention — drawing on two curated knowledge bases rather than
inferring druggability from scratch — so that the leads chosen for structure-based work are those with
a realistic path to a molecule.

## 2. The concept of druggability

The "druggable genome" framing of Hopkins and Groom established that only a subset of human proteins
present binding sites with the physicochemical properties needed to bind drug-like small molecules,
and that membership in privileged protein families (enzymes, GPCRs, nuclear receptors, ion channels)
is a strong prior for tractability [@druggable_genome]. Druggability is therefore not a single number
but a composite of pocket chemistry, protein family, and precedent — which is exactly what the
knowledge bases encode.

## 3. Open Targets: tractability and target class

The **Open Targets Platform** integrates genetic, genomic, and pharmacological evidence to support
systematic target identification and prioritisation [@open_targets]. For each candidate we pulled:

- **Small-molecule tractability bucket** — Open Targets' graded assessment running from "Approved
  drug" (a marketed small molecule exists) through "Advanced clinical", "Phase 1", "Structure with
  ligand / druggable pocket", down to "Discovery precedence" and "Unknown". This bucket is the single
  most informative druggability descriptor because it encodes real-world precedent.
- **Target class** — the protein family (enzyme, transcription factor, membrane receptor, secreted),
  which sets the prior on pocket type and available chemistry.
- **Known drugs and clinical candidates** — the count of molecules already in development against the
  target.

Across the 154 mapped candidates, the tractability distribution was: Approved drug 8, Advanced
clinical 14, Phase 1 1, Druggable pocket 5, Discovery precedence 40, Unknown 86 — i.e. roughly a third
of psoriasis DEGs have at least discovery-level small-molecule precedent.

## 4. ChEMBL: quantitative chemical precedent

Where Open Targets gives a graded label, **ChEMBL** gives the underlying medicinal-chemistry evidence:
a manually curated database of bioactive molecules with measured potencies against protein targets
[@chembl_2024]. For each candidate mapped to a single-protein ChEMBL target we counted **potent
inhibitors**, defined by the standardized **pChEMBL** value — a harmonized −log10 activity (IC50/Ki/EC50)
that makes potencies comparable across assays [@pchembl]. A pChEMBL ≥ 7 threshold (≤ 100 nM) counts
genuinely potent chemical matter.

The inhibitor counts sharply stratified the candidates: RORC (RORγt) 9,766 potent inhibitors, JAK3
6,069, versus STAT3 just 112 — a quantitative reflection of how much tractable chemistry each pocket
has attracted.

## 5. Disease-axis relevance guards against off-target tractability

Raw tractability can mislead: a gene may be highly druggable because of an *unrelated* drug program
(a neurotransmitter receptor, a renin inhibitor) that has nothing to do with psoriasis. We therefore
annotated each candidate with its **psoriasis disease axis** — Th17/IL-17, JAK-STAT, NF-κB/TNF,
innate/antimicrobial, chemokine/leukocyte, tryptophan/immunometabolism, eicosanoid/protease, and
proliferation. This axis layer is what keeps the downstream lead selection mechanistically coherent
rather than merely chemically convenient. The biological grounding for the dominant axes is
well established: RORγt as the master transcription factor of the IL-17-producing T-helper lineage
[@rorgt_th17], the IL-17 cytokine family as central effectors of tissue inflammation [@il17_biology],
STAT3 as the node linking activated keratinocytes to the immune infiltrate in psoriasis
[@stat3_sano], and JAK3 as an essential kinase in cytokine-receptor signaling whose loss causes
immunodeficiency [@jak3_immunity].

## 6. Deliverables

- **`druggability_annotation.csv`** — 154 candidates with tractability bucket, target class, known-drug
  count, potent-inhibitor count, and disease axis.
- **`fig_druggability_landscape.png`** — the druggability landscape, positioning each candidate by DE
  evidence versus chemical/structural tractability.

## 7. Caveats

- Knowledge-base annotations are a snapshot; tractability buckets and inhibitor counts evolve as new
  chemistry is deposited.
- 14 candidates (lincRNAs, uncharacterized clones) did not map to a protein target and carry no
  druggability annotation.

## References
