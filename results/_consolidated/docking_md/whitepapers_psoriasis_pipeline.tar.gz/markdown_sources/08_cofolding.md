# White Paper 8 — Structure-based cross-check by co-folding

**Pipeline step:** Structure-based cross-check on top hits
**Inputs:** top docking hits, lead domain sequences
**Outputs:** `psoriasis_cofolding_package.tar.gz` (Boltz-2 YAMLs, scripts, domain FASTA)

---

## 1. Purpose

Docking scores carry known biases (rigid receptor, empirical scoring). An independent method that does
not share those biases provides a valuable cross-check. This step packages a **co-folding + affinity**
validation of the top docking hits using Boltz-2 — a model that predicts the protein–ligand complex
structure *and* a binding-affinity estimate from sequence and chemistry alone.

## 2. The method: Boltz-2 co-folding

**Boltz-2** is an open-weights biomolecular structure predictor in the AlphaFold3 family: given
protein sequence(s) and ligand(s), it jointly predicts the 3D complex and reports per-interface
confidence, together with an optional small-molecule **binding-affinity** head [@boltz2]. It builds on
the Boltz-1 architecture [@boltz1], which democratized AlphaFold3-style complex modeling in an
openly-licensed implementation. The affinity head is what makes Boltz-2 a genuine orthogonal check: it
scores binding through a learned model rather than a docking scoring function.

## 3. Why co-folding is a true cross-check

Docking places a ligand into a fixed pocket and scores the pose; co-folding *predicts the entire
complex* from sequence, allowing the protein to adopt a ligand-appropriate conformation. Agreement
between a docking score and a co-folding affinity/interface-confidence is therefore strong evidence for
a genuine binder, while disagreement flags a hit for manual inspection or MD. The approach descends
from the AlphaFold2 breakthrough in learned structure prediction [@alphafold2].

## 4. Package design

The co-folding package (`psoriasis_cofolding_package.tar.gz`) contains:

- **11 ready RORγt inputs** — YAML specifications for the top-10 docking hits plus the crystal ligand
  VYI as a positive control, each with the affinity head enabled.
- **Domain constructs** — the exact sequence used for each lead (RORγt LBD, STAT3 core+SH2, JAK3
  kinase), matching the docking receptors, provided as FASTA. Using the domain rather than the
  full-length protein keeps the prediction focused and GPU-efficient.
- **STAT3 and JAK3 templates** — to be populated with their docking hits from the full screen.
- **GPU SLURM array** — one prediction per task; the multiple-sequence-alignment step uses the
  ColabFold MSA server [@colabfold] (or precomputed alignments on an air-gapped node).
- **Cross-check aggregation** — a script that merges Boltz-2 interface confidence (ipTM) and affinity
  probability with the Vina scores into a single comparison table.

## 5. Reading the output

Per prediction, three numbers matter: **ipTM** (interface confidence; > 0.5 is the community pass
line), **affinity probability** (0–1 binder score, the value to rank by), and **predicted affinity**
(log10 IC50 in µM). A hit is corroborated when a strong Vina score coincides with high Boltz-2 binder
probability and interface confidence; the VYI positive control should score as a confident binder.

## 6. Deliverables

- **`psoriasis_cofolding_package.tar.gz`** — YAML inputs, domain FASTA, GPU SLURM runner, and the
  docking cross-check aggregation script.

## 7. Caveats

- The Boltz-2 affinity head caps ligands at 128 heavy atoms; larger ligands (e.g. STAT3 degrader
  chemistry) yield a structure but no affinity.
- Co-folding confidence is a model estimate, not an experimental measurement; it strengthens or
  weakens a docking hypothesis but does not confirm binding.

## References
