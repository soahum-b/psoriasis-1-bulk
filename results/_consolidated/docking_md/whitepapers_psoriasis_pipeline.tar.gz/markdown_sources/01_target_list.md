# White Paper 1 — Assembling the ranked DEG target list

**Pipeline step:** Assemble ranked DEG target list
**Inputs:** `meta_de_PPvsNN.csv` (meta-analysis differential expression), pathway/regulon evidence
**Outputs:** `target_universe.csv`, `fig_target_volcano_annotated.png`

---

## 1. Purpose

The starting point of any target-discovery pipeline is a defensible list of disease-associated
genes. In psoriasis, the relevant contrast is **lesional (PP) versus non-lesional (NN) skin**: genes
whose expression changes between the two states are candidate drivers of the psoriatic phenotype.
This white paper documents how we converted a raw meta-analysis differential-expression (DE) table
into a ranked, evidence-weighted target universe of 2,379 significant genes, and why each analytical
choice was made.

## 2. Differential expression as the primary signal

### 2.1 Why RNA-seq differential expression

Psoriasis is a disease of dysregulated transcription — keratinocyte hyperproliferation and a
type-17 immune infiltrate both leave strong transcriptomic footprints. The reference psoriasis
transcriptome study of Li and colleagues established that lesional skin carries thousands of
differentially expressed genes relative to uninvolved skin, and that these genes are enriched for
immune and epidermal-differentiation programs [@li_psoriasis]. That result is the biological
justification for treating the PP-vs-NN DE table as the primary evidence layer.

### 2.2 Data provenance: recount3 and GENCODE

Uniform quantification matters when combining studies. The upstream expression matrices were drawn
from **recount3**, which reprocesses tens of thousands of human RNA-seq samples through a single
pipeline so that counts are comparable across studies [@recount3]. Gene models follow the **GENCODE**
annotation, the reference human gene set that defines the transcript boundaries and gene identifiers
used throughout [@gencode_v26; @gencode].

### 2.3 The linear-modeling framework: limma-voom

Per-study DE was computed with the **limma** framework, which fits gene-wise linear models and
applies empirical-Bayes moderation of the variance — borrowing information across genes to stabilize
the per-gene error estimate, which is decisive when per-group sample sizes are modest [@limma]. Because
RNA-seq data are counts with a strong mean–variance relationship, raw counts violate the constant-variance
assumption of linear models. The **voom** transformation solves this by estimating the mean–variance
trend and converting it into precision weights on log-counts-per-million, so that ordinary linear
modeling becomes valid on sequencing data [@voom]. The limma-voom pairing is the workhorse of the
per-study analysis.

## 3. Combining studies: random-effects meta-analysis

Individual psoriasis cohorts differ in platform, depth, and patient composition, so effect sizes are
not identical across studies — they are drawn from a distribution. We therefore combined per-study
log-fold-changes with a **random-effects meta-analysis** using the DerSimonian–Laird estimator of
between-study variance (τ²), which explicitly models heterogeneity rather than assuming a single true
effect [@dersimonian_laird]. Each gene's meta-analytic summary carries a combined effect (logFC), its
standard error, a z-statistic, and a heterogeneity index (I²). For STAT3, the meta-analysis returned
logFC = +1.25 (up in lesional skin), z = 5.54, and I² = 91%, the last indicating substantial but
directionally-consistent cross-study heterogeneity.

## 4. Multiple-testing control

Testing ~23,000 genes simultaneously guarantees false positives at any fixed per-test α. We controlled
the **false discovery rate (FDR)** with the Benjamini–Hochberg procedure, which bounds the expected
proportion of false discoveries among the genes called significant and is the standard for
genome-wide expression screens [@benjamini_hochberg]. Combined with an effect-size floor, the
significance rule was **FDR < 0.05 and |log₂FC| > 1**, yielding **2,379 significant meta-DEGs**
(996 up, 1,383 down).

## 5. Layering pathway and regulatory evidence

A gene that is both differentially expressed *and* central to a psoriasis-relevant pathway is a
stronger candidate than one that is merely differentially expressed. Two orthogonal evidence layers
were added:

- **Pathway leading-edge membership.** Gene-set enrichment analysis (GSEA) identifies coordinately
  regulated gene sets and reports the "leading-edge" subset that drives each enrichment
  [@gsea]. Genes in the leading edge of psoriasis-relevant Hallmark sets (e.g. IL6-JAK-STAT3
  signaling, TNFα-via-NF-κB, interferon-γ response) were flagged.
- **Transcription-factor regulon membership.** TF-activity inference with the **CollecTRI** regulon
  collection [@collectri], run through the **decoupleR** statistical framework [@decoupler], identifies
  targets of key transcription factors. STAT3's regulon (435 targets) was used to flag genes under its
  transcriptional control.

## 6. The composite evidence score

The four evidence layers were combined into a single ranking statistic:

```
evidence_score = 0.35 z(|logFC|) + 0.30 z(-log10 FDR)
               + 0.15 z(robustness) + 0.20 z(pathway_support)
```

where `robustness = k (1 - I2/100)` rewards genes replicated across studies (k) with low
heterogeneity, and each term is z-scored across the significant set. The weighting privileges effect
size and statistical confidence while giving meaningful credit to cross-study robustness and pathway
centrality. The result is `target_universe.csv`, the ranked list that all downstream steps consume.

## 6b. From ranked list to interaction map

The ranked target universe is a list, and a list treats genes as independent. Because disease
phenotypes emerge from the coordinated action of interacting proteins [@network_medicine], the
significant DEG set is also passed to a protein–protein interaction network analysis (see the
companion explainer, White Paper 1b) that identifies the network-central "hub" proteins organizing the
psoriatic response — a step that, in this project, independently placed STAT3 at the topological
crossroads of the disease wiring.

## 7. Deliverables

- **`target_universe.csv`** — 2,379 significant genes with per-gene meta-statistics, evidence layers,
  and the composite score.
- **`fig_target_volcano_annotated.png`** — volcano plot (meta-analytic logFC vs -log10 FDR) with the
  lead targets and key psoriasis genes labeled.

## 8. Caveats

- Meta-analytic effect sizes for high-I² genes (STAT3 among them) should be read as directionally
  robust but quantitatively uncertain.
- The evidence-score weights are a defensible but not unique choice; the underlying per-gene statistics
  are provided so the ranking can be recomputed under alternative weightings.

## References
