# White Paper 4 — Retrieving structures for the lead targets

**Pipeline step:** Retrieve structures for lead targets
**Inputs:** lead list (STAT3, RORC, JAK3), UniProt accessions
**Outputs:** `STAT3_6NJS.pdb`, `RORC_5APH.pdb`, `JAK3_5LWM.pdb`, `structure_inventory.csv`, `fig_lead_structures.png`

---

## 1. Purpose

Structure-based drug discovery needs an atomic-resolution model of the target's binding site. This
step selects, for each lead, a high-quality experimental structure with a bound ligand — the ligand
both marks the druggable pocket and provides a positive control for later docking.

## 2. Sources: UniProt and the PDB

Target identity was fixed through **UniProt**, the universal protein knowledgebase, which provides the
canonical sequence and accession for each lead (STAT3 P40763, RORC P51449, JAK3 P52333) and the
cross-references to structural entries [@uniprot_2023]. Experimental structures were retrieved from the
**Protein Data Bank (PDB)**, the global archive of macromolecular structures [@pdb]. Searching the PDB
by UniProt accession returns every deposited structure of the protein, which we then filtered by
method, resolution, and ligand content.

## 3. Selection criteria

For each lead we preferred structures that were:

1. **X-ray, high resolution** (≤ ~2.7 Å) — for reliable side-chain placement in the pocket;
2. **Ligand-bound** — a bound small molecule marks the orthosteric/functional site and anchors the
   docking box;
3. **Domain-appropriate** — covering the domain relevant to intervention (SH2/core for STAT3, the
   ligand-binding domain for RORγt, the kinase ATP site for JAK3).

Ligand identity was read directly from the structure's HETATM records and title rather than trusting a
single metadata field, because ligand annotations in automated feeds are inconsistent.

## 4. Selected structures

| Lead | PDB | Resolution | Domain | Reference ligand |
|------|-----|-----------|--------|------------------|
| **STAT3** | 6NJS | 2.70 Å | SH2 / core | KQV (degrader-class) |
| **RORC / RORγt** | 5APH | 1.54 Å | Ligand-binding domain (LBD) | VYI |
| **JAK3** | 5LWM | 1.55 Å | Kinase domain (ATP site) | 79T |

STAT3 has no crystal structure at the standard resolution cutoff under its primary accession; the
search was broadened and 6NJS (the SH2/core in complex with a degrader-class compound) selected as the
best available handle. RORγt and JAK3 both offered sub-1.6 Å ligand complexes — excellent starting
points.

## 5. Downstream preparation

From each selected structure we extracted the reference ligand, computed the **pocket center** as the
ligand centroid, and defined an initial docking box as the ligand bounding box padded by 16 Å. These
pocket centers seed both the pocket-detection step (White Paper 5) and the docking box (White Paper 7).
Where a full-length model is later needed for co-folding, **AlphaFold2** provides high-accuracy
predicted structure as a complement to the experimental coordinates [@alphafold2].

## 6. Deliverables

- **`STAT3_6NJS.pdb`, `RORC_5APH.pdb`, `JAK3_5LWM.pdb`** — the selected structures.
- **`structure_inventory.csv`** — all candidate structures with resolution, method, ligand, and domain.
- **`fig_lead_structures.png`** — Cα-ribbon overview of the three lead structures.

## 7. Caveats

- A single crystal form captures one conformational snapshot; pocket shape can differ in solution
  (addressed later by MD, White Paper 9).
- STAT3's best structure is a degrader complex, consistent with the difficulty of the classical SH2
  pocket.

## References
