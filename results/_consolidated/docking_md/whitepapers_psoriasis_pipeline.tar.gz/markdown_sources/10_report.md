# White Paper 10 — Compiling the report and deliverables

**Pipeline step:** Compile report and deliverables
**Inputs:** all upstream artifacts (tables, structures, figures, packages)
**Outputs:** `CONSOLIDATED_REPORT.md`, `lead_pipeline_summary.csv`, `fig_pipeline_funnel.png`

---

## 1. Purpose

The final step assembles the pipeline's outputs into a coherent, self-documenting deliverable set: a
consolidated report, a master summary table, and a pipeline overview figure — each written so that a
reader (here, a clinician collaborator) can follow the logic from psoriasis differential expression to
cluster-ready simulation packages without reading the code.

## 2. What the pipeline produced

The pipeline flows through a clear funnel:

- **2,379** significant meta-analysis DEGs (PP vs NN, FDR < 0.05 & |log₂FC| > 1);
- **154** protein-coding candidates annotated for druggability;
- **~28** tractable, on-psoriasis-axis targets;
- **3** structure-ready leads — **STAT3, RORC (RORγt), JAK3** — forming a continuous JAK-STAT/Th17
  signaling axis;
- **1** target (RORγt) taken through a validated 151-compound docking screen, with all three leads
  packaged for cluster-scale docking, co-folding, and MD.

## 3. The deliverable set

**Analysis tables:** `target_universe.csv`, `druggability_annotation.csv`, `druggable_target_ranking.csv`,
`pocket_report.csv`, `docking_ranked.csv`, `lead_pipeline_summary.csv`.

**Structures:** the three lead structures and the top-hit complex (`RORC_tophit_complex.pdb`).

**Cluster packages:** `psoriasis_docking_package.tar.gz` (full-scale docking, all 3 targets),
`psoriasis_cofolding_package.tar.gz` (Boltz-2 GPU cross-check), `psoriasis_md_package.tar.gz`
(equilibrated OpenMM systems).

**Figures:** volcano, druggability landscape, target ranking, lead structures, pocket druggability,
library properties, docking results, top-hit pose, and the pipeline funnel.

**Reports:** `CONSOLIDATED_REPORT.md` (the narrative synthesis) and this white-paper set (per-step
deep dives with references).

## 4. Reproducibility and provenance

Every figure and table is a tracked artifact with code lineage, and every methodological choice is
documented in the per-step white papers. Two caveats are carried consistently through every artifact:
the screening library is ChEMBL-bioactivity-sourced with purchasability pending ZINC22 recovery; and
STAT3's shallow SH2 pocket makes it a degrader/MD target rather than a classical-docking one.

## 5. How to run the packaged work

Each cluster package is self-contained (`environment.yml`, prepared inputs, SLURM scripts, README) and
runs from a single `sbatch` after extraction: the docking package scales the screen across nodes; the
co-folding package runs the Boltz-2 GPU cross-check on the top hits; and the MD package runs production
from the pre-equilibrated systems and analyzes the trajectories.

## 6. Clinical framing

This is research and informational output, not clinical guidance. The leads and compounds identified
are computational hypotheses that require experimental validation; therapeutic decisions must be made
by qualified professionals with full patient context.

---

*This white-paper set documents each pipeline step with references to the primary literature that
established the methods and concepts used. All references are verified against CrossRef.*
