# White Paper 3 — Scoring, ranking, and lead selection

**Pipeline step:** Score and rank druggable targets; select leads
**Inputs:** `druggability_annotation.csv`, `target_universe.csv`
**Outputs:** `druggable_target_ranking.csv`, `fig_target_ranking.png`, `lead_rationale.md`

---

## 1. Purpose

This step fuses the disease-genetics evidence (White Paper 1) and the druggability evidence (White
Paper 2) into a single ranking, then applies a mechanistic filter to select the three leads carried
into structure-based work: **STAT3, RORC (RORγt), and JAK3**.

## 2. The composite druggability score

Each of the 154 annotated targets received a composite score combining seven normalized terms across
three evidence blocks:

```
druggability_score =
   DE:           0.18 s_effect + 0.12 s_signif
   pathway:      0.15 s_pathway
   druggability: 0.16 s_tractability + 0.12 s_chem + 0.12 s_drugs
   structure:    0.15 s_struct
```

Each `s_*` is a min–max-normalized feature: `s_effect`/`s_signif` from the meta-analysis, `s_pathway`
from leading-edge/regulon membership, `s_tractability` from the Open Targets bucket
[@open_targets], `s_chem` from ChEMBL potent-inhibitor count [@chembl_2024], `s_drugs` from
known-drug count, and `s_struct` from availability of a ligand-bound experimental structure. The
weighting deliberately balances "is this gene important in psoriasis" against "can this protein be
drugged", so that neither a strong-but-undruggable nor a druggable-but-irrelevant target dominates.

## 3. Why a raw score is not enough

The raw top of the ranking included targets whose tractability derives from drug programs unrelated
to psoriasis (histamine and serotonin receptors, renin). A high score built on off-axis chemistry is
a false lead. We therefore filtered the ranked pool by three simultaneous conditions:

1. **On a psoriasis disease axis** (mechanistic relevance);
2. **Structure-ready** (a ligand-bound experimental structure exists);
3. **Tractability bucket ≥ Phase-1/structure level** (real small-molecule precedent).

The concept of restricting to privileged, mechanistically-grounded targets follows directly from the
druggable-genome framework [@druggable_genome].

## 4. The three leads and their rationale

Applying the filter and reading the mechanism gives a coherent **JAK–STAT / Th17 signaling axis**:

| Lead | Role in psoriasis | Direction | Tractability | Potent inhibitors |
|------|-------------------|-----------|--------------|-------------------|
| **JAK3** | Upstream kinase feeding cytokine-receptor signaling | up (+1.55) | Approved-drug class | 6,069 |
| **STAT3** | Transcription factor linking keratinocytes and immune infiltrate | up (+1.25) | Discovery precedence | 112 |
| **RORC / RORγt** | Master transcription factor of the Th17 lineage | down (−2.47) | Phase-1 small molecule | 9,766 |

The axis is mechanistically continuous: **JAK3 → STAT3 → RORγt → IL-17**. JAK3 was designated the
most classically tractable node (approved-drug kinase class); RORγt the best tractable transcription
factor with a genuine ligand-binding pocket; STAT3 the user's designated target of primary interest.
STAT3 ranked 43rd on the raw composite but was retained by design — it is the biological anchor of the
project — and its inclusion is transparently a mechanistic rather than a score-driven choice.

## 5. Deliverables

- **`druggable_target_ranking.csv`** — all 154 targets with per-block sub-scores and the composite.
- **`fig_target_ranking.png`** — ranked bar chart with the three leads highlighted.
- **`lead_rationale.md`** — narrative justification for the three-lead selection.

## 6. Caveats

- STAT3's retention is a deliberate override of the pure score; this is stated openly rather than
  hidden by re-weighting.
- The score is a prioritisation aid, not a ground truth; secondary candidates (NOS2, MMP9/12, IDO1,
  PLK1/AURKA) remain in the table for follow-up.

## References
