#!/usr/bin/env python
"""
Aggregate Boltz-2 co-folding + affinity outputs into one ranked table and
cross-check against the docking scores.

Usage:
    python aggregate_cofolding.py --out_dir out --docking docking_ranked.csv \
        --result cofolding_crosscheck.csv
"""
import os, glob, json, argparse, csv

def find(pred_dir, pat):
    hits=glob.glob(os.path.join(pred_dir,pat))
    return hits[0] if hits else None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out_dir",default="out")
    ap.add_argument("--docking",default=None,help="optional docking_ranked.csv to merge")
    ap.add_argument("--result",default="cofolding_crosscheck.csv")
    args=ap.parse_args()

    dock={}
    if args.docking and os.path.exists(args.docking):
        for r in csv.DictReader(open(args.docking)):
            dock[r["ligand"]]=r

    rows=[]
    for rd in sorted(glob.glob(f"{args.out_dir}/boltz_results_*")):
        name=os.path.basename(rd).replace("boltz_results_","")
        pred=os.path.join(rd,"predictions",name)
        conf=find(pred,"confidence_*_model_0.json")
        aff =find(pred,"affinity_*.json")
        row={"ligand":name.replace("RORC_","")}
        if conf:
            c=json.load(open(conf))
            row["iptm"]=c.get("iptm"); row["complex_plddt"]=c.get("complex_plddt")
            row["confidence_score"]=c.get("confidence_score")
        if aff:
            a=json.load(open(aff))
            row["affinity_pred_log10_uM"]=a.get("affinity_pred_value")
            row["affinity_prob_binder"]=a.get("affinity_probability_binary")
        if row["ligand"] in dock:
            row["vina_affinity"]=dock[row["ligand"]].get("affinity")
        rows.append(row)

    # rank by Boltz binder probability
    rows.sort(key=lambda r: -(r.get("affinity_prob_binder") or 0))
    if rows:
        cols=["ligand","affinity_prob_binder","affinity_pred_log10_uM","iptm",
              "complex_plddt","confidence_score","vina_affinity"]
        with open(args.result,"w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=cols,extrasaction="ignore")
            w.writeheader(); w.writerows(rows)
        print(f"{len(rows)} complexes -> {args.result}")
        for r in rows[:5]:
            print(f"  {r['ligand']}: P(binder)={r.get('affinity_prob_binder')} "
                  f"ipTM={r.get('iptm')} vina={r.get('vina_affinity')}")
    else:
        print("no Boltz outputs found under", args.out_dir)

if __name__=="__main__":
    main()
