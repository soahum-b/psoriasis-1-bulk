# Co-folding + affinity cross-check — GPU cluster package

Orthogonal, structure-based validation of the top docking hits using **Boltz-2**
(open-weights AF3-class co-folder). For each protein–ligand pair Boltz-2 predicts
the **complex structure** (with ipTM/pLDDT confidence) and a **binding-affinity
estimate** via its affinity head — an independent check that does not share Vina's
scoring assumptions.

## Contents
```
02_cofolding/
├── yaml/
│   ├── RORC_<hit>.yaml          # 11 ready inputs: top-10 RORC docking hits + VYI positive control
│   ├── _TEMPLATE_STAT3.yaml     # fill with STAT3 hit SMILES from package 01
│   └── _TEMPLATE_JAK3.yaml      # fill with JAK3 hit SMILES from package 01
├── sequences/
│   └── domain_constructs.fasta  # the exact domain constructs used (match crystal structures)
└── scripts/
    ├── run_boltz.slurm          # GPU SLURM array (one task per YAML)
    └── aggregate_cofolding.py   # collect confidences + affinities, merge with docking
```

## Quick start
```bash
# 1. Environment (GPU node)
pip install boltz            # MIT, PyPI
# 2. Run the co-folding array (RORC hits are pre-built)
sbatch scripts/run_boltz.slurm
# 3. Aggregate + cross-check vs docking
python scripts/aggregate_cofolding.py --out_dir out \
    --docking ../01_docking/results/RORC/RORC_docking_ranked.csv \
    --result cofolding_crosscheck.csv
```

## Reading the output
Per prediction, in `out/boltz_results_<name>/predictions/<name>/`:
- **`confidence_<name>_model_0.json`** — `iptm` (interface; >0.5 = pass line),
  `complex_plddt` (fold; >0.7 good), `confidence_score` (ranking aggregate).
- **`affinity_<name>.json`** — `affinity_pred_value` = log10(IC50 in µM), lower =
  tighter (0 → 1 µM, −3 → 1 nM); `affinity_probability_binary` = 0–1 binder score
  (**rank hits by this**).
- **`<name>_model_0.pdb`** — the predicted complex (compare pose vs the Vina pose).

## Interpretation logic
A hit is **corroborated** when docking and co-folding agree: strong Vina score
(≤ −9 kcal/mol) **and** Boltz `affinity_probability_binary` high (> 0.5) **and**
interface `iptm` > 0.5. The **VYI positive control** should score as a confident
binder — if it doesn't, treat the RORC affinity predictions cautiously. Disagreement
between the two methods flags a hit for manual inspection or MD (package 03).

## Domain constructs (match the docking receptors)
- **RORC** — LBD from 5APH (243 aa, TEV/cloning tags stripped)
- **STAT3** — core + SH2 from 6NJS (523 aa)
- **JAK3** — kinase domain from 5LWM (290 aa)

## Notes
- Boltz affinity head caps ligands at **128 heavy atoms**; larger ligands get a
  structure but no affinity (the STAT3 KQV degrader-class chemistry can exceed this).
- The MSA step needs outbound network (`--use_msa_server` → api.colabfold.com). On an
  air-gapped node, pre-compute `.a3m` files and reference them under `msa:` in the YAML.
- If `cuequivariance_ops_torch` ImportError: add `--no_kernels` (≈2× slower, identical
  numerics).
